package com.cg.project.client;

import java.io.File;
import java.io.IOException;

import com.cg.project.readwritework.ReadWriteWork;
import com.cg.project.readwritework.SerializationDemo;

public class MainClass {
	public static void main(String[] args)throws ClassNotFoundException {
		try {
			//File file=new File("d:\\DataFile.txt");
		
			/*if(!file.exists()) {
				file.createNewFile();
			}
			System.out.println(file.canWrite());
			System.out.println(file.canExecute());
			System.out.println(file.getName());
			System.out.println(file.getAbsolutePath());
			System.out.println(file.getPath());
			System.out.println(file.length());*/
			
			
			//File fileTo=new File("C:\\temp\\"+fileFrom.getName());
			//ReadWriteWork.byteStreamReadWrite(fileFrom, fileTo);
			
			/*File fileFrom=new File(".//resources//project.properties");
			ReadWriteWork.propertiesWork(fileFrom);*/
			File file=new File("d:\\CustomerData.txt");
			SerializationDemo.doSerialization(file);
			SerializationDemo.doSerialization(file);
			
		}catch (IOException e) {
			e.printStackTrace();
		}
	}
}
