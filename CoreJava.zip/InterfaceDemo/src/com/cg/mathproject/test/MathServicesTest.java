package com.cg.mathproject.test;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.mathproject.exceptions.NegativeNumberException;
import com.cg.mathproject.services.MathServices;
import com.cg.mathproject.services.MathservicesImpl;

public class MathServicesTest {
	private static MathServices services;

	@BeforeClass
	public static void SetUpTestEnv() {
		services=new MathservicesImpl();
	}
	
	//Add
	@Test(expected=NegativeNumberException.class)
	public void testaddForFirstNumberInvalid()throws NegativeNumberException{
		services.add(-100, 200);
	}

	@Test(expected=NegativeNumberException.class)
	public void testaddForSecondNumberInvalid()throws NegativeNumberException{
		services.add(100, -200);
	}

	@Test
	public void testAddForBothValidNumber()throws NegativeNumberException{
		Assert.assertEquals(300, services.add(100, 200));	
	}
	
	//Subtraction
	@Test(expected=NegativeNumberException.class)
	public void testSubForFirstNumberInvalid()throws NegativeNumberException{
		services.sub(-300, 100);
	}

	@Test(expected=NegativeNumberException.class)
	public void testSubForSecondNumberInvalid()throws NegativeNumberException{
		services.sub(300, -100);
	}

	@Test
	public void testSubForBothValidNumber()throws NegativeNumberException{
		Assert.assertEquals(200, services.sub(300, 100));	
	}
	
	//Division
	@Test(expected=NegativeNumberException.class)
	public void testDivForFirstNumberInvalid()throws NegativeNumberException{
		services.div(-400, 200);
	}

	@Test(expected=NegativeNumberException.class)
	public void testDivForSecondNumberInvalid()throws NegativeNumberException{
		services.div(400, -200);
	}

	@Test
	public void testDivForBothValidNumber()throws NegativeNumberException{
		Assert.assertEquals(2, services.div(400, 200));	
	}
	
	//Multiplication
	@Test(expected=NegativeNumberException.class)
	public void testMultiForFirstNumberInvalid()throws NegativeNumberException{
		services.multi(-300, 200);
	}

	@Test(expected=NegativeNumberException.class)
	public void testMultiForSecondNumberInvalid()throws NegativeNumberException{
		services.multi(300, -200);
	}

	@Test
	public void testMultiForBothValidNumber()throws NegativeNumberException{
		Assert.assertEquals(60000, services.multi(300, 200));	
	}

	@AfterClass
	public static void tearDownTestEnv() {
		services=null;
	}
}


