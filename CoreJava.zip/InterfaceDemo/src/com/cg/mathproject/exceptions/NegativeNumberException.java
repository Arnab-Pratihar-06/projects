package com.cg.mathproject.exceptions;

public class NegativeNumberException extends Exception{

	public NegativeNumberException() {
		super();
	}

	public NegativeNumberException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public NegativeNumberException(String message, Throwable cause) {
		super(message, cause);
	}

	public NegativeNumberException(String message) {
		super(message);
	}

	public NegativeNumberException(Throwable cause) {
		super(cause);
	}

}
