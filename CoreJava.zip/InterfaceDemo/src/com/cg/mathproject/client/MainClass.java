package com.cg.mathproject.client;

import com.cg.mathproject.services.MathServices;
import com.cg.mathproject.services.MathservicesImpl;

public class MainClass {
	public static void main(String[] args) {
		MathServices services=new MathservicesImpl();
		
	}

}
