
public class MainClass {

	public static void main(String[] args) {
		int num = 100;
		Integer n=num;
		System.out.println(" 'Autoboxing'- value :"+n);
		
		Integer m=100;
		Integer m2=num+m+m+200;
		System.out.println(" 'Auto-Unboxing'-  value : "+m2);
		System.out.println(+m);
	}

}
