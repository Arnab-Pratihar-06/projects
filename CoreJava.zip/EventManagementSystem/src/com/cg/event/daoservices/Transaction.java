package com.cg.event.daoservices;

public class Transaction {

}
