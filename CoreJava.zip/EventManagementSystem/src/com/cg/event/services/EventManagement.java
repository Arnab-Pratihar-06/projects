package com.cg.event.services;

public class EventManagement {

}
