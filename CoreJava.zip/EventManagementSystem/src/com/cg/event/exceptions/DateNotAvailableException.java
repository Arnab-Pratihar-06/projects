package com.cg.event.exceptions;

public class DateNotAvailableException extends Exception{

	public DateNotAvailableException() {
		super();
	}

	public DateNotAvailableException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public DateNotAvailableException(String message, Throwable cause) {
		super(message, cause);
	}

	public DateNotAvailableException(String message) {
		super(message);
	}

	public DateNotAvailableException(Throwable cause) {
		super(cause);
	}
}
