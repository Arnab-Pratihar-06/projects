package com.cg.event.util;

public class EventDBUtil {

}
