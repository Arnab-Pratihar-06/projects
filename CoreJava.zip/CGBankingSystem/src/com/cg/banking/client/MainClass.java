package com.cg.banking.client;

import java.util.Scanner;
import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingservicesImpl;

public class MainClass {

	public static void main(String[] args) {
		long accNo,accNoFrom,accNoTo;
		int pinNo;
		float amt;

		BankingServices services=new BankingservicesImpl();
		Account cust1=null;
		Account cust2=null;
		try {
			cust1=services.openAccount("SAVINGS",3000);
			cust1.setAccountStatus("ACTIVE");
		}catch(InvalidAccountTypeException|InvalidAmountException|BankingServicesDownException e) {
			e.printStackTrace();
		}
		
		try {
			cust2=services.openAccount("CURRENT",5000);
			cust2.setAccountStatus("ACTIVE");
		}catch(InvalidAccountTypeException|InvalidAmountException|BankingServicesDownException e) {
			e.printStackTrace();
		}

		System.out.println("Account details: "+cust1);
		System.out.println("Account details:"+cust2);
		Scanner sc=new Scanner(System.in);
		System.out.println();
		System.out.println("														   			    ' WITHDRAW ' ");
		System.out.println("Enter Account number : ");
		accNo=sc.nextLong();
		System.out.println("Enter PIN number : ");
		pinNo=sc.nextInt();
		System.out.println("Enter Amount to Withdraw : ");
		amt=sc.nextFloat();
		try {
			System.out.println(services.withdrawAmount(accNo,amt,pinNo));
			System.out.println("Account details after Withdrawl "+services.getAccountDetails(accNo));
		}catch(InsufficientAmountException|AccountNotFoundException|InvalidPinNumberException|BankingServicesDownException|AccountBlockedException e) {
			e.printStackTrace();
		}
		System.out.println();
		System.out.println("															 			  'DEPOSIT' ");
		System.out.println("Enter Account Number : ");
		accNo=sc.nextLong();
		System.out.println("Enter Amount to Deposit : ");
		amt=sc.nextFloat();
		try {
			System.out.println(services.depositAmount(accNo,amt));
			System.out.println("Account Details After Deposit "+services.getAccountDetails(accNo));
		}catch(AccountNotFoundException|BankingServicesDownException|AccountBlockedException e) {
			e.printStackTrace();
		}
		System.out.println();
		System.out.println("														  				'FUND-TRANSFER' ");
		System.out.println("Enter Account Number <from> where To Withdraw : ");
		accNoFrom=sc.nextLong();
		System.out.println("Enter PIN  Number : ");
		pinNo=sc.nextInt();
		System.out.println("Enter Account Number where <to> deposit:");
		accNoTo=sc.nextLong();
		System.out.println("Enter Transfer Amount");
		amt=sc.nextFloat();
		try {
			System.out.println("Fund Transfer Status : "+services.fundTransfer(accNoTo,accNoFrom,amt,pinNo));
			System.out.println("Account Details After Fund Transfer : \n"+services.getAccountDetails(accNoTo)+"\n"+"\n(from\n)"+services.getAccountDetails(accNoFrom));
		}
		catch(InsufficientAmountException|AccountNotFoundException|InvalidPinNumberException|BankingServicesDownException|AccountBlockedException e) {
			e.printStackTrace();
		}
		sc.close();
	}
}
