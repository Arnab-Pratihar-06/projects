package com.cg.payroll.client;
import com.cg.payroll.exceptions.AssociateDetailsNotfoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		PayrollServices services=new PayrollServicesImpl();
		int associateId=services.acceptAssociateDetails("Arnab", "Pratihar", "arnab@gmail.com", "YTP", "Analyst", "1357", 20000, 200000, 1200, 120, 7545,"ICICIBANK","abcd1234");
		int associateId2=services.acceptAssociateDetails("Debu", "Basu", "debu@gmail.com", "YTP", "Analyst", "1564", 34000, 400000, 1250, 1200, 7545,"ICICIBANK","abcd1234");
		System.out.println("Associate Id "+associateId);
		System.out.println("Associate Id "+associateId2);
		try {
			System.out.println();
			System.out.println("For Associate ID <101>");
			System.out.println();
			System.out.println("Net Annual Salary   = "+services.calculateNetSalary(associateId));
			System.out.println("Net Monthly Salary    = "+(services.calculateNetSalary(associateId))/12);
			double basicSalary=services.getAssociateDetails(associateId).getSalary().getBasicSalary();
			double netSalary=services.calculateNetSalary(associateId);
			double tax=basicSalary-netSalary;
			System.out.println("Annual Tax   =  "+tax);
			System.out.println("Monthly Tax   = "+tax/12);
		} catch (AssociateDetailsNotfoundException e) {
			e.printStackTrace();
		}
		
		try {
			System.out.println("\n");
			System.out.println("For Associate ID <102>");
			System.out.println();
			System.out.println("Net Annual Salary   = "+services.calculateNetSalary(associateId2));
			System.out.println("Net Monthly Salary   = "+(services.calculateNetSalary(associateId2))/12);
			double basicSalary=services.getAssociateDetails(associateId2).getSalary().getBasicSalary();
			double netSalary=services.calculateNetSalary(associateId2);
			double tax=basicSalary-netSalary;
			System.out.println("Annual Tax   =  "+tax);
			System.out.println("Monthly Tax   = "+tax/12);
		} catch (AssociateDetailsNotfoundException e) {
			e.printStackTrace();
		}
	}
}