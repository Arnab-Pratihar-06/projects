package com.cg.project.client;
import com.cg.equals.beans.Employee;

public class MainClass {
	public static void main(String[] args) {
		Employee emp1=new Employee(112,"Arnab","Pratihar",15000);
		Employee emp2=new Employee(112,"Arnab","Pratihar",15000);
		if(emp1==emp2)
		{
			System.out.println("Same reference!");
		}
		else
		{
			System.out.println("Not same reference! ");
		}
		if(emp1.equals(emp2))
		{
			System.out.println("Same data!");
		}
		else
		{
			System.out.println("Different data!");
		}
	}

}
