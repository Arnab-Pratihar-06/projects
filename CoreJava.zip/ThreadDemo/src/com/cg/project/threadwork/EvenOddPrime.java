package com.cg.project.threadwork;

public class EvenOddPrime implements Runnable{

	@Override
	public void run() {
		int flag=1;
		int n=100;
		Thread t=Thread.currentThread();
		for(int i=2;i<=n;i++)
		{
			if(i%2==0)
				System.out.println("Even    "+i);
			else
				System.out.println("Odd    "+i);
				
		}
	}

}
