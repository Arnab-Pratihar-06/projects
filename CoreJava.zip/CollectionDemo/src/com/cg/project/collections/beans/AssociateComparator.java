package com.cg.project.collections.beans;

import java.util.Comparator;

public class AssociateComparator implements Comparator<Associate>{

	@Override
	public int compare(Associate o1, Associate o2) {
		return 0;
	}
}
