package com.cg.project.client;

import java.util.ArrayList;

import com.cg.project.collection.ListClassesDemo;
import com.cg.project.collections.beans.Associate;

public class MainClass {

	public static void main(String[] args) {
		ArrayList<Associate>strList=new ArrayList<Associate>();
		
		strList.add(new Associate(2506, "Arnab", "Pratihar", 15000));
		strList.add(new Associate(1928, "Debu", "Basu", 18000));
		strList.add(new Associate(4502, "Nikhil", "Sharma", 14000));
		strList.add(new Associate(7520, "Ayush", "Gupta", 25000));
		ListClassesDemo.arrayListClassDemo();
	}

}
