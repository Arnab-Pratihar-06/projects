package com.cg.project.collection;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Set;

import com.cg.project.collections.beans.Associate;

public class MapClassesDemo {
	public static void HashTableClassWord(){
		Hashtable<Integer,Associate> associates=new Hashtable<>();
		associates.put(2506, new Associate(2506, "Arnab", "Pratihar", 15000));
		associates.put(1928,new Associate(1928, "Debu", "Basu", 18000));
		associates.put(2506,new Associate(2506, "Nikhil", "Sharma", 14000));
		associates.put(7520,new Associate(7520, "Ayush", "Gupta", 25000));
		
		Associate associate=associates.get(112);
		associates.remove(112);
		
		Set<Integer>keys=associates.keySet();
		
		for(Integer key : keys) {
			System.out.println(associates.get(key));
		}
		ArrayList<Associate> associateList=new ArrayList<>(associates.values());
		
	} 

}
