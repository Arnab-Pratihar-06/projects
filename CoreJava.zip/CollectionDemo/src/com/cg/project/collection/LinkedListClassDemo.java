package com.cg.project.collection;

import java.util.LinkedList;

import com.cg.project.collections.beans.Associate;

public class LinkedListClassDemo {
	public static void LinkedListClassDemo()
	{
		LinkedList<Associate> associates=new LinkedList<>();
		
		associates.add(new Associate(2506, "Arnab", "Pratihar", 15000));
		associates.add(new Associate(1928, "Debu", "Basu", 18000));
		associates.add(new Associate(4502, "Nikhil", "Sharma", 14000));
		associates.add(new Associate(7520, "Ayush", "Gupta", 25000));
	}

}
