package com.cg.project.collection;

import java.util.ArrayList;
import java.util.Collections;
import com.cg.project.collections.beans.Associate;
import com.cg.project.collections.beans.AssociateComparator;


public class ListClassesDemo {
	public static void arrayListClassDemo() {
		ArrayList<Associate>associates=new ArrayList<>();
		//Sorting
		
		Collections.sort(associates);
		for(Associate associate : associates) {
			System.out.println(associate);
		}
		System.out.println("==========");
		Collections.sort(associates,new AssociateComparator());
		
		for(Associate associate : associates) {
			System.out.println(associate);
		}
	}
}

